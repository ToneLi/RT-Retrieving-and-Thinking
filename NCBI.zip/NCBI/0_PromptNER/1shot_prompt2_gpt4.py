from logging import log
import openai
import json

import time
import torch
import json
from tqdm import tqdm
from torch.utils.data import DataLoader, RandomSampler, SequentialSampler, TensorDataset

openai.api_key = "key"

if torch.cuda.is_available():
    device = torch.device("cuda")
    print(torch.cuda.device_count())
    print('Available:', torch.cuda.get_device_name(0))
else:
    print('No GPU available, using the CPU instead.')
    device = torch.device("cpu")

SYSTEM_PROMPT = "An entity is DiseaseClass, SpecificDisease,CompositeMention or Modifier. Sports, sporting events, adjectives, verbs, numbers, adverbs, abstract concepts, sports, are not entities. Dates, years and times are not entities. Possessive words like I, you, him and me are not entities."
USER_PROMPT_1 = "Are you clear about your role?"
ASSISTANT_PROMPT_1 = "Sure, I'm ready to help you with your NER task. Please provide me with the necessary information to get started."


def openai_chat_completion_response(final_prompt):
    response = openai.ChatCompletion.create(
        timeout=600,
        max_tokens=390,
        model="gpt-4",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": USER_PROMPT_1},
            {"role": "assistant", "content": ASSISTANT_PROMPT_1},
            {"role": "user", "content": final_prompt}
        ]
    )

    return response['choices'][0]['message']['content'].strip(" \n")


class Bertbiofewreader():
    def __init__(self, file=None):
        # super().__init__()
        # self.tokenizer = BertTokenizer.from_pretrained(pretrainedfile)
        if file is not None:
            self.init(file)

    def getinstance(self, data):
        text = ' '.join(data['tokens'])
        labels = ["O"] * len(data['tokens'])
        # print("self.label2id",self.label2id)

        entitys = []

        for entity in data['entity']:
            if entity['type'] in self.target_classes:
                entitys.append(entity)
                for i in range(entity['offset'][0], entity['offset'][1]):
                    if i == entity['offset'][0]:
                        label = 'I-' + entity['type']
                    else:
                        label = 'I-' + entity['type']
                    labels[i] = label
        field = {
            'inputtext': data['tokens'],
            'labels': labels,
        }
        return field

    def init(self, file, labels=None):
        self.dataset = []
        self.labels = []
        with open(file) as f:
            for line in f:
                line = json.loads(line)
                # print(line.keys())
                class_count = {}
                for entity in line['entity']:
                    if entity['type'] not in self.labels:
                        self.labels.append(entity['type'])
                    if entity['type'] not in class_count:
                        class_count[entity['type']] = 1
                    else:
                        class_count[entity['type']] += 1
                line['class_count'] = class_count
                self.dataset.append(line)
        if labels is not None:
            self.labels = labels
        self.target_classes = self.labels

    def buildlabel2id(self):
        self.label2id = {}
        # print(" self.target_classes", self.target_classes)
        for label in self.target_classes:
            if label != 'O':
                # self.label2id['B-' + label] = len(self.label2id)
                self.label2id['I-' + label] = len(self.label2id)
            else:
                self.label2id[label] = len(self.label2id)

    def text_to_instance(self, idx=None, label=True, dataset=None, target_classes=None):
        results = []
        if dataset is not None:
            self.dataset = dataset
        # print("target_classes",target_classes)
        if target_classes is not None:
            # print("------------------fucccccccccccc")
            self.target_classes = target_classes
            self.buildlabel2id()

        if idx is None:
            for data in self.dataset:
                results.append(self.getinstance(data))
        else:
            for index in idx:
                results.append(self.getinstance(self.dataset[index]))
        if idx is None:
            idx = list(range(len(self.dataset)))
        return results, self.label2id

    def _read(self, file):
        with open(file) as f:
            for line in f:
                yield self.text_to_instance(json.loads(line))


def get_prediction(b_input_text, predictions):
    word_label = {}
    for label, words in predictions.items():
        for word in words:
            if word not in word_label:
                word_label[word] = label
    prediction_labels = ""
    for word in b_input_text.split(" "):
        if word in word_label:
            prediction_labels = prediction_labels + word_label[word] + " "
        else:
            prediction_labels = prediction_labels + "O" + " "
    prediction_labels = prediction_labels.strip()
    return prediction_labels


def finetuning(testreader, file, batch_size, out_putfile):
    fw = open(out_putfile, "w", encoding="utf-8")
    with open(file) as f:
        support_number = -1
        for line in f:
            support_number += 1
            dataset = json.loads(line)
            support = dataset['support']
            target_classes_ = dataset['target_label']
            target_classes = []
            for labe in target_classes_:
                if labe != "O":
                    target_classes.append(labe)
            constraint = 'bio_decay'
            target_classes.append('O')
            if 'bio' in constraint:
                id2label = []
                for label in target_classes:
                    if label != 'O':
                        # id2label.append('B-' + label)
                        id2label.append('I-' + label)
                    else:
                        id2label.append(label)
            else:
                id2label = target_classes

            query_set, _ = testreader.text_to_instance(None, target_classes=target_classes)
            query_data_loader = DataLoader(query_set, batch_size, shuffle=False)

            flag = 0
            ps = 0
            rs = 0
            f1s = 0
            for batch in tqdm(query_data_loader):
                flag = flag + 1
                b_input_text = [word[0] for word in batch["inputtext"]]
                b_labels = [word[0].replace("I-", "") for word in batch["labels"]]
                # print("-------")
                print("-flag", flag)
                # print(b_input_text)
                # print(b_input_labels)
                # DiseaseClass, SpecificDisease,CompositeMention,Modifier
                GUIDELINES_PROMPT = (
                    "Examples:\n"
                    "\n"
                    "1. Sentence: HFE mutations analysis in 711 hemochromatosis probands: evidence for S65C implication in mild form of hemochromatosis . Hereditary hemochromatosis ( HH ) is a common autosomal recessive genetic disorder of iron metabolism. The HFE candidate gene encoding an HLA class I-like protein involved in HH was identified in 1996. Two missense mutations have been described C282Y, \n"
                    "Output: 1. hemochromatosis|True|as it is a Modifier  2.Hereditary|True| as it is a SpecificDisease 3. HH|True| as it is a SpecificDisease 4. autosomal|True| as it is a DiseaseClass 5. recessive|True|as it is a DiseaseClass 6. genetic|True|as it is a DiseaseClass 6. disorder|True|as it is a DiseaseClass  7. 1996|False|as it is a number 8. mutations|False|as it is a medical word\n"
                    "2. Sentence: ALPS ) is a disorder of lymphocyte homeostasis and immunological tolerance \n"
                    "Output: 1. ALPS|True|as it is a SpecificDisease  2.disorder of lymphocyte homeostasis and immunological tolerance|True| as it is a CompositeMention 3. )|False| as it is a special symbols\n"
                    "\n"
                    "3. Sentence: {}\n"
                    "Output: "
                )
                # print(b_input_text)

                if flag >= 0:
                    b_input_text = " ".join(b_input_text)
                    GUIDELINES_PROMPT = GUIDELINES_PROMPT.format(b_input_text)
                    Dic_={}
                    predictions = openai_chat_completion_response(GUIDELINES_PROMPT)
                    Pre = predictions.replace("'", "\"")
                    # predictions = [x.strip() for x in predictions]
                    # fw.write(str(b_input_text) + "\t")
                    Dic_["sentence"]=str(b_input_text)
                    Dic_["pre_labels"]=Pre
                    Dic_["gold_labels"] = " ".join(b_labels)
                    json_str = json.dumps(Dic_)
                    fw.write(json_str)
                    fw.write("\n")
                    fw.flush()

                    time.sleep(5)
            break


def getseqeval(pred, gold, id2label, bio=False):
    goldlabel = [[] for i in range(gold.shape[0])]
    predlabel = [[] for i in range(gold.shape[0])]
    for i in range(gold.shape[0]):
        for j in range(gold.shape[1]):
            if gold[i, j] >= 0:
                g = id2label[gold[i][j]]
                p = id2label[pred[i][j]]
                if not bio:
                    if g != 'O':
                        g = 'I-' + g
                    if p != 'O':
                        p = 'I-' + p
                goldlabel[i].append(g)
                predlabel[i].append(p)
    return goldlabel, predlabel


if __name__ == "__main__":
    pretrainedfile = 'AshtonIsNotHere/GatorTron-OG'
    inputfile = "1shot_NCBI.json"
    out_putfile = "promptNER_gpt4_output_shot1_NCBI.json"
    testreader = Bertbiofewreader('test_NCBI.json')
    batch_size = 1
    finetuning(testreader, inputfile, batch_size, out_putfile)


