"""

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
"""